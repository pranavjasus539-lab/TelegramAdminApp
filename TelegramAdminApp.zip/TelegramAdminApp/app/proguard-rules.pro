# Keep command classes and their names for reflection-free registry lookups (none currently
# needed, but this keeps stack traces readable if you extend the app later).
-keepattributes SourceFile,LineNumberTable
-keep class com.example.telegramadmin.commands.** { *; }
-keep class com.example.telegramadmin.telegram.model.** { *; }
-dontwarn okhttp3.**
-dontwarn okio.**
