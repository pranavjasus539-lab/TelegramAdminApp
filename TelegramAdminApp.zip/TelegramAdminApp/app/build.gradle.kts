import java.util.Properties
import java.io.FileInputStream

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// --- Config resolution: local.properties file wins, then environment variables, then blank. ---
// This is the Android-idiomatic stand-in for ".env" / "appsettings.json": local.properties is
// never committed (see .gitignore) and env vars work the same as they would in any CI system.
val localProps = Properties().apply {
    val f = rootProject.file("local.properties")
    if (f.exists()) FileInputStream(f).use { load(it) }
}

fun configValue(propKey: String, envKey: String): String =
    localProps.getProperty(propKey)
        ?: System.getenv(envKey)
        ?: ""

val defaultBotToken = configValue("botToken", "TELEGRAM_BOT_TOKEN")
val defaultOwnerId = configValue("ownerId", "TELEGRAM_OWNER_ID")

android {
    namespace = "com.example.telegramadmin"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.telegramadmin"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        // Baked-in fallback defaults. Both may be blank; the app then falls back to its
        // runtime config file / Settings screen. Never logged, never shown in full in the UI.
        buildConfigField("String", "DEFAULT_BOT_TOKEN", "\"$defaultBotToken\"")
        buildConfigField("String", "DEFAULT_OWNER_ID", "\"$defaultOwnerId\"")
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
        debug {
            isMinifyEnabled = false
        }
    }

    buildFeatures {
        buildConfig = true
        viewBinding = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    testOptions {
        unitTests.isReturnDefaultValues = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.lifecycle:lifecycle-service:2.8.4")
    implementation("androidx.work:work-runtime-ktx:2.9.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    testImplementation("junit:junit:4.13.2")
    // The android.jar used on the unit-test classpath only contains stubs for org.json that throw
    // at runtime. This pulls in a real implementation just for tests, so JSONObject actually works
    // without needing Robolectric for every single test class.
    testImplementation("org.json:json:20240303")
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.8.1")
    testImplementation("io.mockk:mockk:1.13.11")
    testImplementation("org.robolectric:robolectric:4.13")
    testImplementation("androidx.test:core:1.6.1")
}
