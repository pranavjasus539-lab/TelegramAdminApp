package com.example.telegramadmin.config

import android.content.Context
import android.util.Log
import com.example.telegramadmin.BuildConfig
import org.json.JSONObject
import java.io.File

/**
 * Single source of truth for bot configuration.
 *
 * Resolution order (highest priority first):
 *   1. Runtime config file at filesDir/config.json - written by the in-app Settings screen,
 *      this is the Android equivalent of an "appsettings.json" the user can edit without
 *      rebuilding the app.
 *   2. Build-time defaults baked in from local.properties / environment variables
 *      (TELEGRAM_BOT_TOKEN, TELEGRAM_OWNER_ID) via BuildConfig fields - see app/build.gradle.kts.
 *
 * If neither source has a valid value, [load] returns a config with [BotConfig.isValid] == false
 * and the caller (MainActivity) should prompt the user before starting the service.
 */
class ConfigManager(private val context: Context) {

    private val configFile: File
        get() = File(context.filesDir, "config.json")

    fun load(): BotConfig {
        readRuntimeConfig()?.let { if (it.isValid) return it }

        val token = BuildConfig.DEFAULT_BOT_TOKEN
        val ownerId = BuildConfig.DEFAULT_OWNER_ID.toLongOrNull() ?: 0L
        return BotConfig(token, ownerId)
    }

    fun save(botToken: String, ownerId: Long) {
        val json = JSONObject().apply {
            put("botToken", botToken)
            put("ownerId", ownerId)
        }
        try {
            configFile.writeText(json.toString())
        } catch (e: Exception) {
            Log.e(TAG, "Failed writing runtime config file", e)
            throw ConfigException("Could not save config: ${e.message}", e)
        }
    }

    private fun readRuntimeConfig(): BotConfig? {
        if (!configFile.exists()) return null
        return try {
            val json = JSONObject(configFile.readText())
            BotConfig(
                botToken = json.optString("botToken", ""),
                ownerId = json.optLong("ownerId", 0L)
            )
        } catch (e: Exception) {
            Log.e(TAG, "Runtime config file is corrupt, ignoring it", e)
            null
        }
    }

    companion object {
        private const val TAG = "ConfigManager"
    }
}

class ConfigException(message: String, cause: Throwable? = null) : Exception(message, cause)
