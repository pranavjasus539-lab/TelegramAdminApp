package com.example.telegramadmin.commands.impl

import android.app.ActivityManager
import android.content.Context
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import com.example.telegramadmin.commands.Command
import com.example.telegramadmin.commands.CommandContext

class StatusCommand : Command {
    override val name = "status"
    override val description = "Battery, storage, memory and device info"

    override suspend fun execute(ctx: CommandContext): String {
        val context = ctx.appContext
        val battery = batteryInfo(context)
        val storage = storageInfo()
        val memory = memoryInfo(context)

        return buildString {
            appendLine("📊 System status")
            appendLine("Device: ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}")
            appendLine("Android: ${android.os.Build.VERSION.RELEASE} (SDK ${android.os.Build.VERSION.SDK_INT})")
            appendLine("Battery: $battery")
            appendLine("Storage free: $storage")
            append("Memory free: $memory")
        }
    }

    private fun batteryInfo(context: Context): String {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
        val pct = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
        val charging = bm?.isCharging ?: false
        return if (pct >= 0) "$pct%${if (charging) " (charging)" else ""}" else "unknown"
    }

    private fun storageInfo(): String {
        return try {
            val stat = StatFs(Environment.getDataDirectory().path)
            val freeBytes = stat.availableBytes
            val totalBytes = stat.totalBytes
            "${formatBytes(freeBytes)} free of ${formatBytes(totalBytes)}"
        } catch (e: Exception) {
            "unknown (${e.message})"
        }
    }

    private fun memoryInfo(context: Context): String {
        return try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val info = ActivityManager.MemoryInfo()
            am.getMemoryInfo(info)
            "${formatBytes(info.availMem)} free of ${formatBytes(info.totalMem)}"
        } catch (e: Exception) {
            "unknown (${e.message})"
        }
    }

    private fun formatBytes(bytes: Long): String {
        val gb = bytes / (1024.0 * 1024.0 * 1024.0)
        return if (gb >= 1) "%.1f GB".format(gb) else "%.0f MB".format(bytes / (1024.0 * 1024.0))
    }
}
