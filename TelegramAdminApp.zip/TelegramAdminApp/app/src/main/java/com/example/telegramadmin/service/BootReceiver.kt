package com.example.telegramadmin.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.core.content.ContextCompat
import com.example.telegramadmin.AdminApp

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return

        val app = context.applicationContext as AdminApp
        val config = app.configManager.load()
        if (!config.isValid) {
            Log.i(TAG, "Skipping auto-start after boot: no valid config yet.")
            return
        }

        Log.i(TAG, "Boot completed, starting bot service.")
        val serviceIntent = Intent(context, BotForegroundService::class.java)
        ContextCompat.startForegroundService(context, serviceIntent)
    }

    companion object {
        private const val TAG = "BootReceiver"
    }
}
