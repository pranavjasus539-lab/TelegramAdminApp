package com.example.telegramadmin.commands

import android.content.Context
import com.example.telegramadmin.config.BotConfig
import com.example.telegramadmin.telegram.TelegramClient
import com.example.telegramadmin.telegram.model.IncomingMessage

/** Everything a command needs to do its job, bundled so new commands take one constructor param. */
data class CommandContext(
    val appContext: Context,
    val client: TelegramClient,
    val config: BotConfig,
    val message: IncomingMessage,
    /** Everything after the command word, already trimmed. Empty string if no args given. */
    val args: String,
    /** Wall-clock time (millis) the foreground service started, for uptime reporting. */
    val serviceStartedAtMillis: Long,
    /** Lets a command ask the service to stop itself after replying (used by /stop). */
    val requestServiceStop: () -> Unit
)

/**
 * A single chat command. To add a new one:
 *   1. Implement this interface in commands/impl/.
 *   2. Register an instance in [CommandRegistry.buildDefault].
 * That's the entire extension surface - nothing else needs to change.
 */
interface Command {
    /** Lowercase, without the leading slash, e.g. "status". */
    val name: String
    /** One line shown in /help. */
    val description: String

    suspend fun execute(ctx: CommandContext): String
}
