package com.example.telegramadmin.commands.impl

import com.example.telegramadmin.commands.Command
import com.example.telegramadmin.commands.CommandContext
import com.example.telegramadmin.telegram.TelegramApiException
import com.example.telegramadmin.util.FileAccess

class GetFileCommand : Command {
    override val name = "get"
    override val description = "Send a file from the phone into this chat, e.g. /get ~/Download/log.txt"

    override suspend fun execute(ctx: CommandContext): String {
        if (ctx.args.isBlank()) return "Usage: /get <path>"
        if (!FileAccess.canAccessAllFiles()) {
            return "⚠️ Storage permission not granted yet. Open the app and tap " +
                "\"Grant All files access\", then try again."
        }

        val file = FileAccess.resolve(ctx.args)
        if (!file.exists() || !file.isFile) return "❌ File not found: ${file.path}"

        return try {
            ctx.client.sendDocument(ctx.message.chatId, file)
            "" // the document itself is the reply; no extra text message needed
        } catch (e: TelegramApiException) {
            "❌ Upload failed: ${e.message}"
        }
    }
}
