package com.example.telegramadmin.telegram.model

import org.json.JSONObject

/** A single incoming Telegram update, trimmed down to the fields this app actually needs. */
data class IncomingMessage(
    val updateId: Long,
    val chatId: Long,
    val fromId: Long,
    val text: String?,
    val documentFileId: String?,
    val documentFileName: String?,
    val caption: String?
) {
    companion object {
        /** Returns null for update types we don't care about (edits, callbacks, other chats, etc). */
        fun fromJson(update: JSONObject): IncomingMessage? {
            val updateId = update.optLong("update_id", -1L)
            if (updateId < 0) return null

            val message = update.optJSONObject("message") ?: return null
            val chat = message.optJSONObject("chat") ?: return null
            val from = message.optJSONObject("from")

            val document = message.optJSONObject("document")

            return IncomingMessage(
                updateId = updateId,
                chatId = chat.optLong("id"),
                fromId = from?.optLong("id") ?: chat.optLong("id"),
                text = message.optString("text").ifBlank { null },
                documentFileId = document?.optString("file_id"),
                documentFileName = document?.optString("file_name"),
                caption = message.optString("caption").ifBlank { null }
            )
        }
    }
}
