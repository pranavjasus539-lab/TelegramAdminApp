package com.example.telegramadmin

import android.app.Application
import com.example.telegramadmin.commands.CommandRegistry
import com.example.telegramadmin.config.ConfigManager

class AdminApp : Application() {

    lateinit var configManager: ConfigManager
        private set

    val commandRegistry: CommandRegistry by lazy { CommandRegistry.buildDefault() }

    override fun onCreate() {
        super.onCreate()
        configManager = ConfigManager(this)
    }
}
