package com.example.telegramadmin.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.telegramadmin.AdminApp
import com.example.telegramadmin.R
import com.example.telegramadmin.commands.CommandContext
import com.example.telegramadmin.commands.IncomingFileHandler
import com.example.telegramadmin.telegram.TelegramApiException
import com.example.telegramadmin.telegram.TelegramClient
import com.example.telegramadmin.telegram.model.IncomingMessage
import com.example.telegramadmin.ui.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * The whole bot lives here: one long-lived coroutine that long-polls Telegram, dispatches
 * commands, and reconnects with exponential backoff on any failure. Runs as a foreground
 * service (type dataSync) so Android doesn't kill it for being an idle background process.
 */
class BotForegroundService : Service() {

    private val job = SupervisorJob()
    private val scope = CoroutineScope(job)
    private var pollLoopJob: Job? = null

    private lateinit var client: TelegramClient
    private var serviceStartedAtMillis = 0L

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        serviceStartedAtMillis = System.currentTimeMillis()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val app = application as AdminApp
        val config = app.configManager.load()

        startForegroundWithNotification(connected = false)

        if (!config.isValid) {
            Log.e(TAG, "No valid bot token / owner ID configured; stopping.")
            stopSelf()
            return START_NOT_STICKY
        }

        client = TelegramClient(config.botToken)

        // Avoid stacking a second poll loop if onStartCommand fires again (e.g. START_STICKY redelivery).
        if (pollLoopJob?.isActive != true) {
            pollLoopJob = scope.launch {
                runPollLoop(config.ownerId)
            }
        }
        return START_STICKY
    }

    private suspend fun runPollLoop(ownerId: Long) {
        client.deleteWebhook()
        var offset = 0L
        var backoffMs = INITIAL_BACKOFF_MS

        while (job.isActive) {
            try {
                val updates = client.getUpdates(offset)
                if (updates.isNotEmpty()) {
                    updateNotification(connected = true)
                    backoffMs = INITIAL_BACKOFF_MS // reset backoff after any success
                }
                for (message in updates) {
                    offset = maxOf(offset, message.updateId + 1)
                    handleMessage(message, ownerId)
                }
            } catch (e: TelegramApiException) {
                Log.w(TAG, "Poll failed, backing off ${backoffMs}ms: ${e.message}")
                updateNotification(connected = false)
                delay(backoffMs)
                backoffMs = (backoffMs * 2).coerceAtMost(MAX_BACKOFF_MS)
            } catch (e: Exception) {
                // Catch-all so one bad update or an unexpected runtime error never kills the loop.
                Log.e(TAG, "Unexpected error in poll loop, continuing", e)
                delay(backoffMs)
                backoffMs = (backoffMs * 2).coerceAtMost(MAX_BACKOFF_MS)
            }
        }
    }

    private suspend fun handleMessage(message: IncomingMessage, ownerId: Long) {
        if (message.fromId != ownerId) {
            Log.w(TAG, "Ignoring message from non-owner id=${message.fromId}")
            return
        }

        val app = application as AdminApp
        val config = app.configManager.load()

        try {
            val reply = if (message.documentFileId != null && message.text?.startsWith("/") != true) {
                val ctx = buildContext(message, config, args = "")
                IncomingFileHandler.handle(ctx)
            } else {
                val text = message.text?.trim().orEmpty()
                if (!text.startsWith("/")) {
                    "Unknown message. Send /help to see available commands."
                } else {
                    val (name, args) = splitCommand(text)
                    val command = app.commandRegistry.find(name)
                    if (command == null) {
                        "Unknown command: /$name\nSend /help to see available commands."
                    } else {
                        val ctx = buildContext(message, config, args)
                        command.execute(ctx)
                    }
                }
            }
            if (reply.isNotBlank()) {
                client.sendMessage(message.chatId, reply)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Command handling failed", e)
            runCatching {
                client.sendMessage(message.chatId, "❌ Command failed: ${e.message}")
            }
        }
    }

    private fun buildContext(
        message: IncomingMessage,
        config: com.example.telegramadmin.config.BotConfig,
        args: String
    ) = CommandContext(
        appContext = applicationContext,
        client = client,
        config = config,
        message = message,
        args = args,
        serviceStartedAtMillis = serviceStartedAtMillis,
        requestServiceStop = { stopSelf() }
    )

    private fun splitCommand(text: String): Pair<String, String> {
        // Supports "/status" and "/status@YourBotName arg1 arg2" (Telegram appends @botname in groups).
        val firstSpace = text.indexOf(' ')
        val rawCommand = if (firstSpace == -1) text else text.substring(0, firstSpace)
        val name = rawCommand.removePrefix("/").substringBefore('@')
        val args = if (firstSpace == -1) "" else text.substring(firstSpace + 1).trim()
        return name to args
    }

    // --- Foreground notification plumbing ---

    private fun startForegroundWithNotification(connected: Boolean) {
        val notification = buildNotification(connected)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val types = ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC or ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
            startForeground(NOTIFICATION_ID, notification, types)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun updateNotification(connected: Boolean) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, buildNotification(connected))
    }

    private fun buildNotification(connected: Boolean): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val text = getString(
            if (connected) R.string.notification_text_connected else R.string.notification_text_reconnecting
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_notification)
            .setOngoing(true)
            .setContentIntent(openAppIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    /** Graceful stop: cancelling the job immediately ends the in-flight getUpdates call/backoff
     * delay, so nothing lingers after the user (or a command) stops the service. */
    override fun onDestroy() {
        Log.i(TAG, "Service stopping, cancelling poll loop")
        job.cancel()
        super.onDestroy()
    }

    companion object {
        private const val TAG = "BotForegroundService"
        private const val CHANNEL_ID = "bot_connection"
        private const val NOTIFICATION_ID = 1
        private const val INITIAL_BACKOFF_MS = 2_000L
        private const val MAX_BACKOFF_MS = 60_000L
    }
}
