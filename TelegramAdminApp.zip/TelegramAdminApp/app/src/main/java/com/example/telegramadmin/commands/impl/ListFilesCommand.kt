package com.example.telegramadmin.commands.impl

import com.example.telegramadmin.commands.Command
import com.example.telegramadmin.commands.CommandContext
import com.example.telegramadmin.util.FileAccess

class ListFilesCommand : Command {
    override val name = "ls"
    override val description = "List a folder, e.g. /ls ~/Download"

    override suspend fun execute(ctx: CommandContext): String {
        if (!FileAccess.canAccessAllFiles()) {
            return "⚠️ Storage permission not granted yet. Open the app and tap " +
                "\"Grant All files access\", then try again."
        }
        val target = FileAccess.resolve(ctx.args)
        if (!target.exists()) return "❌ Not found: ${target.path}"
        if (!target.isDirectory) return "❌ Not a folder: ${target.path}\nUse /get to download a single file."

        val entries = target.listFiles()
            ?: return "❌ Could not read folder (permission denied?): ${target.path}"

        if (entries.isEmpty()) return "📁 ${target.path}\n(empty)"

        val lines = entries.sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
            .joinToString("\n") { f ->
                val marker = if (f.isDirectory) "📁" else "📄"
                val size = if (f.isFile) " (${f.length() / 1024} KB)" else ""
                "$marker ${f.name}$size"
            }
        return "📁 ${target.path}\n$lines"
    }
}
