package com.example.telegramadmin.commands.impl

import com.example.telegramadmin.commands.Command
import com.example.telegramadmin.commands.CommandContext
import com.example.telegramadmin.telegram.TelegramApiException
import com.example.telegramadmin.util.FileAccess
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Zips a folder and sends it as one or more parts, each under 45MB (safely under Telegram's
 * 50MB bot upload limit). A folder that fits in one zip gets one file; anything larger is
 * automatically split into part1.zip, part2.zip, etc. and sent sequentially.
 */
class ZipFolderCommand : Command {
    override val name = "zip"
    override val description = "Zip a folder and send it (auto-splits if over 45MB), e.g. /zip ~/Pictures"

    private val maxPartSize = 45L * 1024 * 1024 // 45 MB per part, safely under Telegram's 50MB limit

    override suspend fun execute(ctx: CommandContext): String {
        if (ctx.args.isBlank()) return "Usage: /zip <folder path>"
        if (!FileAccess.canAccessAllFiles()) {
            return "⚠️ Storage permission not granted yet. Open the app and tap " +
                "\"Grant All files access\", then try again."
        }
        val folder = FileAccess.resolve(ctx.args)
        if (!folder.exists() || !folder.isDirectory) return "❌ Not a folder: ${folder.path}"

        val allFiles = folder.walkTopDown().filter { it.isFile }.sortedBy { it.absolutePath }.toList()
        if (allFiles.isEmpty()) return "📁 Folder is empty: ${folder.path}"

        // Group files into parts, each under maxPartSize
        val parts = mutableListOf<MutableList<File>>()
        var currentPart = mutableListOf<File>()
        var currentSize = 0L

        for (file in allFiles) {
            val fileSize = file.length()
            // If a single file exceeds the limit on its own, warn and skip it
            if (fileSize > maxPartSize) {
                ctx.client.sendMessage(
                    ctx.message.chatId,
                    "⚠️ Skipping ${file.name} (${fileSize / 1024 / 1024}MB — over 45MB limit)"
                )
                continue
            }
            if (currentSize + fileSize > maxPartSize && currentPart.isNotEmpty()) {
                parts.add(currentPart)
                currentPart = mutableListOf()
                currentSize = 0L
            }
            currentPart.add(file)
            currentSize += fileSize
        }
        if (currentPart.isNotEmpty()) parts.add(currentPart)

        if (parts.isEmpty()) return "❌ No files small enough to upload from that folder."

        val totalParts = parts.size
        if (totalParts > 1) {
            ctx.client.sendMessage(
                ctx.message.chatId,
                "📦 Folder is large — splitting into $totalParts parts and sending them now…"
            )
        }

        var successCount = 0
        parts.forEachIndexed { index, files ->
            val partLabel = if (totalParts > 1) "_part${index + 1}of$totalParts" else ""
            val zipFile = File(
                ctx.appContext.cacheDir,
                "${folder.name}${partLabel}_${System.currentTimeMillis()}.zip"
            )
            try {
                createZip(files, folder, zipFile)
                ctx.client.sendDocument(
                    ctx.message.chatId,
                    zipFile,
                    caption = if (totalParts > 1) "${folder.name} — part ${index + 1} of $totalParts" else folder.name
                )
                successCount++
            } catch (e: TelegramApiException) {
                ctx.client.sendMessage(ctx.message.chatId, "❌ Part ${index + 1} upload failed: ${e.message}")
            } catch (e: Exception) {
                ctx.client.sendMessage(ctx.message.chatId, "❌ Part ${index + 1} zip failed: ${e.message}")
            } finally {
                zipFile.delete()
            }
        }

        return if (totalParts > 1) "✅ Sent $successCount of $totalParts parts." else ""
    }

    private fun createZip(files: List<File>, sourceRoot: File, zipFile: File) {
        ZipOutputStream(zipFile.outputStream().buffered()).use { zos ->
            files.forEach { file ->
                val entryName = file.relativeTo(sourceRoot).path
                zos.putNextEntry(ZipEntry(entryName))
                file.inputStream().use { it.copyTo(zos) }
                zos.closeEntry()
            }
        }
    }
}
