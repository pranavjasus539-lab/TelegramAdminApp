package com.example.telegramadmin.commands.impl

import com.example.telegramadmin.commands.Command
import com.example.telegramadmin.commands.CommandContext
import com.example.telegramadmin.telegram.TelegramApiException
import com.example.telegramadmin.util.FileAccess
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Zips a folder into a temporary file in the app's cache dir, uploads it, then deletes the
 * temp zip - so a user pulling a whole photo folder doesn't have to run /get once per file.
 */
class ZipFolderCommand : Command {
    override val name = "zip"
    override val description = "Zip a folder and send it as one file, e.g. /zip ~/Pictures"

    override suspend fun execute(ctx: CommandContext): String {
        if (ctx.args.isBlank()) return "Usage: /zip <folder path>"
        if (!FileAccess.canAccessAllFiles()) {
            return "⚠️ Storage permission not granted yet. Open the app and tap " +
                "\"Grant All files access\", then try again."
        }
        val folder = FileAccess.resolve(ctx.args)
        if (!folder.exists() || !folder.isDirectory) return "❌ Not a folder: ${folder.path}"

        val zipFile = File(ctx.appContext.cacheDir, "${folder.name}_${System.currentTimeMillis()}.zip")
        return try {
            zipFolder(folder, zipFile)
            if (zipFile.length() > 50L * 1024 * 1024) {
                zipFile.delete()
                return "❌ Zipped folder is over Telegram's 50MB upload limit. Try a smaller folder."
            }
            ctx.client.sendDocument(ctx.message.chatId, zipFile, caption = folder.name)
            zipFile.delete()
            ""
        } catch (e: TelegramApiException) {
            zipFile.delete()
            "❌ Upload failed: ${e.message}"
        } catch (e: Exception) {
            zipFile.delete()
            "❌ Could not zip folder: ${e.message}"
        }
    }

    private fun zipFolder(source: File, zipFile: File) {
        ZipOutputStream(zipFile.outputStream().buffered()).use { zos ->
            source.walkTopDown().filter { it.isFile }.forEach { file ->
                val entryName = file.relativeTo(source).path
                zos.putNextEntry(ZipEntry(entryName))
                file.inputStream().use { it.copyTo(zos) }
                zos.closeEntry()
            }
        }
    }
}
