package com.example.telegramadmin.commands.impl

import com.example.telegramadmin.commands.Command
import com.example.telegramadmin.commands.CommandContext

class StopServiceCommand : Command {
    override val name = "stop"
    override val description = "Stop the bot service on the phone (start it again from the app)"

    override suspend fun execute(ctx: CommandContext): String {
        // Reply before the caller tears things down, since requestServiceStop() cancels the
        // polling loop this command is running inside of.
        ctx.client.sendMessage(ctx.message.chatId, "🛑 Stopping. Open the app to start it again.")
        ctx.requestServiceStop()
        return ""
    }
}
