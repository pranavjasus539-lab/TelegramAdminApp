package com.example.telegramadmin.config

/**
 * Resolved runtime configuration for the bot.
 *
 * @param botToken Telegram bot token, e.g. "123456789:AA...".
 * @param ownerId  The single Telegram chat ID allowed to issue commands. Every other chat
 *                 is ignored - this is the entire authorization model, kept deliberately simple.
 */
data class BotConfig(
    val botToken: String,
    val ownerId: Long
) {
    val isValid: Boolean
        get() = botToken.isNotBlank() && ownerId != 0L

    /** Never print the real token; used in logs and status messages. */
    fun redactedToken(): String =
        if (botToken.length <= 8) "****" else botToken.take(4) + "…" + botToken.takeLast(4)
}
