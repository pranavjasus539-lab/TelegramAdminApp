package com.example.telegramadmin.commands

import android.os.Environment
import com.example.telegramadmin.telegram.TelegramApiException
import com.example.telegramadmin.util.FileAccess
import java.io.File

/**
 * Not a slash command - this runs whenever the owner sends a document message. The optional
 * caption is treated as a destination folder, e.g. sending a file with caption "~/Download"
 * saves it there. With no caption, files land in Download/TelegramAdmin/.
 */
object IncomingFileHandler {

    suspend fun handle(ctx: CommandContext): String {
        val fileId = ctx.message.documentFileId ?: return "❌ No file found in that message."
        val fileName = ctx.message.documentFileName ?: "file_${System.currentTimeMillis()}"

        if (!FileAccess.canAccessAllFiles()) {
            return "⚠️ Storage permission not granted yet. Open the app and tap " +
                "\"Grant All files access\", then resend the file."
        }

        val destinationDir = ctx.message.caption
            ?.let { FileAccess.resolve(it) }
            ?: File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "TelegramAdmin")

        return try {
            val filePath = ctx.client.getFilePath(fileId)
            val destination = File(destinationDir, fileName)
            ctx.client.downloadFile(filePath, destination)
            "✅ Saved to ${destination.path}"
        } catch (e: TelegramApiException) {
            "❌ Download failed: ${e.message}"
        } catch (e: Exception) {
            "❌ Could not save file: ${e.message}"
        }
    }
}
