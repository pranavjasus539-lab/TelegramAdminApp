package com.example.telegramadmin.commands.impl

import com.example.telegramadmin.commands.Command
import com.example.telegramadmin.commands.CommandContext

class HelpCommand(private val otherCommands: List<Command>) : Command {
    override val name = "help"
    override val description = "Show this list of commands"

    override suspend fun execute(ctx: CommandContext): String {
        val lines = (otherCommands + this).sortedBy { it.name }.joinToString("\n") {
            "/${it.name} - ${it.description}"
        }
        return "🤖 Available commands:\n$lines"
    }
}
