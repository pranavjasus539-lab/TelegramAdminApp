package com.example.telegramadmin.commands

import com.example.telegramadmin.commands.impl.GetFileCommand
import com.example.telegramadmin.commands.impl.HelpCommand
import com.example.telegramadmin.commands.impl.ListFilesCommand
import com.example.telegramadmin.commands.impl.LocationCommand
import com.example.telegramadmin.commands.impl.OpenFileCommand
import com.example.telegramadmin.commands.impl.PingCommand
import com.example.telegramadmin.commands.impl.RebootDeviceCommand
import com.example.telegramadmin.commands.impl.RestartAppCommand
import com.example.telegramadmin.commands.impl.StatusCommand
import com.example.telegramadmin.commands.impl.StopServiceCommand
import com.example.telegramadmin.commands.impl.ZipFolderCommand

/** Ordered registry of every command the bot understands. Lookup is case-insensitive. */
class CommandRegistry(private val commands: List<Command>) {

    private val byName: Map<String, Command> = commands.associateBy { it.name.lowercase() }

    fun find(name: String): Command? = byName[name.lowercase()]

    fun all(): List<Command> = commands

    companion object {
        /** Builds the registry with every built-in command. HelpCommand needs the final list,
         * so it's added last with a reference to everything registered before it. */
        fun buildDefault(): CommandRegistry {
            val core = listOf(
                PingCommand(),
                StatusCommand(),
                ListFilesCommand(),
                LocationCommand(),
                OpenFileCommand(),
                GetFileCommand(),
                RestartAppCommand(),
                StopServiceCommand(),
                RebootDeviceCommand(),
                ZipFolderCommand()
            )
            val withHelp = core + HelpCommand(core)
            return CommandRegistry(withHelp)
        }
    }
}
