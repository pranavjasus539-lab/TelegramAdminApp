package com.example.telegramadmin.ui

import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.telegramadmin.AdminApp
import com.example.telegramadmin.R
import com.example.telegramadmin.admin.AdminReceiver
import com.example.telegramadmin.config.ConfigException
import com.example.telegramadmin.databinding.ActivityMainBinding
import com.example.telegramadmin.service.BotForegroundService

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var app: AdminApp

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        app = application as AdminApp

        requestNotificationPermissionIfNeeded()
        loadCurrentConfig()
        refreshStatusText()

        binding.saveButton.setOnClickListener { onSaveClicked() }
        binding.startButton.setOnClickListener { startBotService() }
        binding.stopButton.setOnClickListener { stopBotService() }
        binding.grantStorageButton.setOnClickListener { requestAllFilesAccess() }

        if (intent?.getBooleanExtra(EXTRA_AUTOSTART_SERVICE, false) == true) {
            startBotService()
        }
    }

    private fun loadCurrentConfig() {
        val config = app.configManager.load()
        binding.botTokenInput.setText(config.botToken)
        if (config.ownerId != 0L) {
            binding.ownerIdInput.setText(config.ownerId.toString())
        }
    }

    private fun onSaveClicked() {
        val token = binding.botTokenInput.text?.toString()?.trim().orEmpty()
        val ownerIdText = binding.ownerIdInput.text?.toString()?.trim().orEmpty()
        val ownerId = ownerIdText.toLongOrNull()

        if (token.isEmpty() || ownerId == null) {
            toast("Enter both a bot token and a numeric owner chat ID.")
            return
        }

        try {
            app.configManager.save(token, ownerId)
            toast("Saved. Tap \"Start service\" to connect.")
        } catch (e: ConfigException) {
            toast("Could not save config: ${e.message}")
        }
    }

    private fun startBotService() {
        val config = app.configManager.load()
        if (!config.isValid) {
            toast("Save a bot token and owner ID first.")
            return
        }
        val intent = Intent(this, BotForegroundService::class.java)
        ContextCompat.startForegroundService(this, intent)
        refreshStatusText()
        toast("Starting…")
    }

    private fun stopBotService() {
        stopService(Intent(this, BotForegroundService::class.java))
        refreshStatusText()
    }

    private fun refreshStatusText() {
        binding.statusText.text = getString(R.string.status_idle)
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS)
                != android.content.pm.PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
            }
        }
    }

    /** MANAGE_EXTERNAL_STORAGE can only be granted through this system settings screen - it
     * cannot be requested as a normal runtime permission dialog. */
    private fun requestAllFilesAccess() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            toast("Not needed on this Android version.")
            return
        }
        if (Environment.isExternalStorageManager()) {
            toast("Already granted.")
            return
        }
        try {
            val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                data = Uri.parse("package:$packageName")
            }
            startActivity(intent)
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
        }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    companion object {
        const val EXTRA_AUTOSTART_SERVICE = "autostart_service"

        /** Used only by the README's optional Device Owner setup instructions - exposed here so
         * that flow has a stable ComponentName to reference from adb. */
        fun deviceAdminComponent(activity: MainActivity): ComponentName =
            ComponentName(activity, AdminReceiver::class.java)
    }
}
