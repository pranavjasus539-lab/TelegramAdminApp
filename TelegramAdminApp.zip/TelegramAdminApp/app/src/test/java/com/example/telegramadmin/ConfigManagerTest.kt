package com.example.telegramadmin

import androidx.test.core.app.ApplicationProvider
import com.example.telegramadmin.config.ConfigManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class ConfigManagerTest {

    private val context = ApplicationProvider.getApplicationContext<android.app.Application>()

    @Test
    fun `returns invalid config when nothing has been set`() {
        val manager = ConfigManager(context)
        val config = manager.load()
        // BuildConfig defaults are blank in the test build, and no runtime file exists yet.
        assertFalse(config.isValid)
    }

    @Test
    fun `save then load round-trips the runtime config file`() {
        val manager = ConfigManager(context)
        manager.save("test-token-123", 42L)

        val loaded = manager.load()

        assertEquals("test-token-123", loaded.botToken)
        assertEquals(42L, loaded.ownerId)
        assertEquals(true, loaded.isValid)
    }

    @Test
    fun `redactedToken never exposes the full token`() {
        val manager = ConfigManager(context)
        manager.save("123456789:AAExampleFullTokenValue", 1L)
        val redacted = manager.load().redactedToken()
        assertFalse(redacted.contains("ExampleFullTokenValue"))
    }
}
